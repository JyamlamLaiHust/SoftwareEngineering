import xadmin
from goods.models import Goods

"""
class GoodsAdmin(object):
    list_display = ['name', 'click_num', 'sold_num']


xadmin.site.register(Goods, GoodsAdmin)
"""