"""
这是一个模板文件,实际文件按此模板去掉_tmp
内容涉及隐私,故不受Git管理
"""

# 云片网API KEY
YUNPIAN_KEY = ''

# 测试手机号
MY_MOBILE = ''